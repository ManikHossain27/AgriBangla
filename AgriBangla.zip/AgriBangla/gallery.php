<?php include_once ('common/header.php'); ?>

<!--gallery-->
<div class="container-fluid text-center">
	  <p style="font-family: 'Kaushan Script', cursive;padding-top: 70px; font-size: 35px;margin-top: -34px;">গ্যালারী</p>
  <img src="gallery/underline.png" alt="underline" style="width: 250px; margin-top: -55px;"><br>
</div>
<div class="container-fluid">
	<div class="row mt-4">
		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/1.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/1.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>
		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/1.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/1.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/2.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/2.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/3.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/3.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/4.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/4.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/5.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/5.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/6.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/6.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/7.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/7.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/8.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/8.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/9.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/9.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/10.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/10.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/11.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/11.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/12.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/12.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/3.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/3.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/13.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/13.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/14.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/14.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/15.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/15.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/16.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/16.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/18.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/18.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/19.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/19.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/20.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/20.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/21.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/21.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/22.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/22.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/23.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/23.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/24.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/24.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/25.jpg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/25.jpg" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/27.jfif" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/27.jfif" class="rounded" width="100%" height="100%">
			</a>
		</div>

		<div class="item col-sm-6 col-md-4 mb-3">
			<a href="gallery/krishi/29.jpeg" class="fancybox" data-fancybox="gallery1">
				<img src="gallery/krishi/29.jpeg" class="rounded" width="100%" height="100%">
			</a>
		</div>
	</div>
</div>



<?php include_once ('common/footer.php'); ?>

